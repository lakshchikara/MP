# Fashion Store Demo (Flask) – Updated Version

Features:
- Flask + SQLite backend
- 40 products with sample images
- Home page:
  - Hero section (yellow/white design)
  - New Arrivals: 10 products (5 x 2 grid)
  - Unique mood-based outfit picker
- Products page:
  - 40-product grid (5 per row)
  - Sort by price (Low → High / High → Low)
  - Integrated search from navbar
- Auth:
  - Sign in / Sign up slider page
  - Passwords stored hashed
- Cart:
  - Add to cart with bounce animation on cart icon
  - Cart popup (no extra page)
  - Increase / Decrease quantity in cart
  - Total updates automatically
- Payments:
  - Card / UPI / COD options
  - Logos displayed for payment
  - COD shows "Order placed" animation overlay

## Run

1. Create virtual environment (optional):

   ```bash
   python -m venv venv
   # Windows
   venv\Scripts\activate
   # macOS / Linux
   source venv/bin/activate
   ```

2. Install dependencies:

   ```bash
   pip install -r requirements.txt
   ```

3. Run:

   ```bash
   python app.py
   ```

4. Open `http://127.0.0.1:5000` in your browser.
